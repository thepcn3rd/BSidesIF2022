$process_dir = "C:\attachments"

while($true) {

        # If any odt files in attachments, load the file and then archive:
        $files = ls $process_dir\*.odt
        if ( $files.length -gt 0) {
		# Copy the registrymodifications.xcu file back in-place to remove the document recovery
		Copy-Item -Force -Path "C:\files\registrymodifications.xcu" -Destination "C:\users\prayut.c\appdata\roaming\libreoffice\4\user\registrymodifications.xcu"
		Start-Sleep -s 15

                # launch odt files
                Invoke-Item "$($process_dir)\*.odt"
                Start-Sleep -s 60

                # kill libre office, sleep
                Stop-Process -Name soffice*
                Start-Sleep -s 60
		Remove-Item -Recurse -force -Path $process_dir\*
		Remove-Item -Force -Path "c:\users\prayut.c\appdata\roaming\libreoffice\4\user\registrymodifications.xcu"
        }
        Start-Sleep -s 60
}
