#!/usr/bin/python3

import random
import string

# Reference for password randomization
# https://pynative.com/python-generate-random-string/

athletes = ["Chanin Wibunrungrueang", "Phanumat Saengdi", "Duangphet Phromthep", "Somphong Chaiwong", "Mongkhon Bunpiam", "Natthawut Thakhamsong", "Ekkarat Wongsukchan", "Adun Sam-on", "Prachak Sutham", "Phiphat Phothi", "Phonchai Khamluang", "Phiraphat Somphiangchai"]

coaches = ["Ekkaphon Kanthawong (Assistant Coach)", "Ekapol Chanthawong (Coach)", "Nopparat Kanthawong (Head Coach)"]

leaders = ["Prayut Chan-o-cha", "Narongsak Osatanakorn"]

divers = ["Vern Unsworth", "Richard Stanton", "John Volanthen", "Ben Reymenants", "Maksym Polejaka", "Robert Harper", "Richard Harris", "Jason Mallinson", "Chris Jewell", "Craig Challen", "Jim Warny"]

def buildUsers(listUsers, group):
    for a in listUsers:
        print("     - name: Create AD User - " + a)
        print("       win_domain_user:")
        name = a.lower().split(" ")
        fname = name[0]
        lname = name[1]
        print("         name: " + fname + "." + lname[0:1])
        characters = string.ascii_letters + string.digits
        password = ''.join(random.choice(characters) for i in range(18))
        print('         password: "' + password + '"')
        print("         state: present")
        print("         groups_action: add")
        print('         groups: "' + group + '"')
        print("")

buildUsers(athletes, "Athletes")
buildUsers(coaches, "Coaches")
buildUsers(leaders, "Leaders")
buildUsers(divers, "Divers")
