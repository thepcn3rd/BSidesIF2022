#!/bin/bash

# Change the IP Address as needed...
ssh -i keys/ssh.pem ubuntu@54.245.29.84
