#!/bin/bash

ansible-playbook -i inventory.yml configure.yml
